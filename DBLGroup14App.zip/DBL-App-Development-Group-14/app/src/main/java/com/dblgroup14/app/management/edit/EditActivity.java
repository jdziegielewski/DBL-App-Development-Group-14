package com.dblgroup14.app.management.edit;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import com.dblgroup14.app.R;

public class EditActivity extends AppCompatActivity {
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);
        
        // TODO: Determine whether to edit existing object or to create a new one
    }
}
